import './bootstrap';
import './custom';

import jQuery from 'jquery';
import Alpine from 'alpinejs';

window.$ = window.jQuery = jQuery;
window.Alpine = Alpine;

Alpine.start();
